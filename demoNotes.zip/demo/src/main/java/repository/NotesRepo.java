package repository;

import entity.Notes;

public class NotesRepo extends MongoRepository<Notes, Integer> {
}
