package controller;

import entity.Notes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import repository.NotesRepo;

import java.util.List;

@RestController
public class NotesController {
    @Autowired
    private NotesRepo notesRepo;

    @PostMapping("/addNotes")
        public String addNotes( @RequestBody Notes notes) {
            notesRepo.save(notes);
            return "added successfully";
        }
        @GetMapping("/getNotes")
        public List<Notes> getNotes(){
        return notesRepo.findAll();
        }
}
